<header>
    <img src="layouts/assets/img/atas.jpeg" alt="" width="1200" height="100">
</header>
<h2></h2>

<h3>
    <div class="info">Selamat datang, <strong>di SampahCash</strong></div>
</h3>
<div class="info">Ayo Memilah Sampah agar Lingkungan Tetap terjaga</div>