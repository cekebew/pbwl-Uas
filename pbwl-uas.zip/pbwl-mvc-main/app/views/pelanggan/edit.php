<h2>Edit Riwayat</h2>

<form action="<?php echo URL; ?>/pelanggan/update" method="post">
    <table>
        <input type="hidden" name="pel_id" value="<?php echo $data['row']['pel_id']; ?>">
        <tr>
            <td>TANGGAL PEMBAYARAN</td>
            <td><input type="text" name="pel_no" value="<?php echo $data['row']['pel_no']; ?>"></td>
        </tr>
        <tr>
            <td>JUMLAH</td>
            <td><input type="text" name="pel_nama" value="<?php echo $data['row']['pel_nama']; ?>"></td>
        </tr>
        <tr>
            <td>NAMA</td>
            <td><input type="text" name="pel_ktp" value="<?php echo $data['row']['pel_ktp']; ?>"></td>
        </tr>
        <tr>
            <td>N0.TELEPON</td>
            <td><input type="text" name="pel_hp" value="<?php echo $data['row']['pel_hp']; ?>"></td>
        </tr>


        <tr>
            <td></td>
            <td> <input type="submit" name="btn_update" value="UPDATE"></td>
        </tr>
    </table>
</form>