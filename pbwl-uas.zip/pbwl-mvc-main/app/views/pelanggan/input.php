<h2>Input riwayat</h2>

<form action="<?php echo URL; ?>/pelanggan/simpan" method="post">
    <table>
        <tr>
            <td>TANGGAL PEMBAYARAN</td>
            <td><input type="text" name="pel_no"></td>
        </tr>
        <tr>
            <td>JUMLAH</td>
            <td><input type="text" name="pel_nama"></td>
        </tr>
        <tr>
            <td>NAMA</td>
            <td><input type="text" name="pel_hp"></td>
        </tr>
        <tr>
            <td>ALAMAT</td>
            <td><input type="text" name="pel_hp"></td>
        </tr>
        <tr>
            <td>NO.TELEPON</td>
            <td><input type="text" name="pel_ktp"></td>
        </tr>



        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>