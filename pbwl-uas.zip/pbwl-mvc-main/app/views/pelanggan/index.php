<header>
      <img src="layouts/assets/img/atas.jpeg" alt="" width="1200" height="100">
</header>

<h2>Riwayat</h2>

<a href="<?php echo URL; ?>/pelanggan/input" class="btn">Tambah</a>

<table>
      <tr>
            <th>NO</th>
            <th>TANGGAL PEMBAYARAN</th>
            <th>JUMLAH</th>
            <th>NAMA</th>
            <th>ALAMAT</th>
            <th>NO.TELEPON</th>


            <th>OPSI</th>
      </tr>

      <?php foreach ($data['rows'] as $row) { ?>
            <tr>
                  <td><?php echo $row['pel_id']; ?></td>
                  <td><?php echo $row['pel_nama']; ?></td>
                  <td><?php echo $row['pel_alamat']; ?></td>
                  <td><?php echo $row['pel_hp']; ?></td>
                  <td><?php echo $row['pel_seri']; ?></td>
                  <td><?php echo $row['pel_meteran']; ?></td>


                  <td>
                        <a href="<?php echo URL; ?>/pelanggan/edit/<?php echo $row['pel_id']; ?>" class="btn">Edit</a>
                        <a href="<?php echo URL; ?>/pelanggan/delete/<?php echo $row['pel_id']; ?>" class="btn">Delete</a>
                  </td>
            </tr>
      <?php } ?>

</table>