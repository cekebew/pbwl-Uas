<h2>Edit Transaksi</h2>

<form action="<?php echo URL; ?>/user/update" method="post">
    <table>
        <input type="hidden" name="user_id" value="<?php echo $data['row']['user_id']; ?>">
        <tr>
            <td>TANGGAL</td>
            <td><input type="text" name="user_nama" value="<?php echo $data['row']['user_nama']; ?>"></td>
        </tr>
        <tr>
            <td>NAMA</td>
            <td><input type="text" name="user_password" value="<?php echo $data['row']['user_password']; ?>"></td>
        </tr>
        <tr>
            <td>ALAMAT</td>
            <td><textarea name="user_alamat" id="" cols="30" rows="5"><?php echo $data['row']['user_alamat']; ?></textarea></td>
        </tr>
        <tr>
            <td>TOTAL PEMBAYARAN</td>
            <td><input type="text" name="user_hp" value="<?php echo $data['row']['user_hp']; ?>"></td>
        </tr>
        <tr>
            <td>KETERANGAN</td>
            <td><input type="text" name="user_email" value="<?php echo $data['row']['user_email']; ?>"></td>
        </tr>

        <tr>
            <td></td>
            <td><input type="submit" name="btn_update" value="UPDATE"></td>
        </tr>
    </table>
</form>