<h2>Input Transaksi</h2>

<form action="<?php echo URL; ?>/user/simpan" method="post">
    <table>
        <tr>
            <td>TANGGAL</td>
            <td><input type="text" name="user_nama"></td>
        </tr>
        <tr>
            <td>NAMA</td>
            <td><input type="text" name="user_password"></td>
        </tr>
        <tr>
            <td>ALAMAT</td>
            <td><textarea name="user_alamat" id="" cols="30" rows="5"></textarea></td>
        </tr>
        <tr>
            <td>TOTAL PEMBAYARAN</td>
            <td><input type="text" name="user_hp"></td>
        </tr>
        <tr>
            <td>KETERANGAN</td>
            <td><input type="text" name="user_email"></td>
        </tr>

        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form><br><br><br><br>